package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SketchTagger extends AppCompatActivity {
    private ImageView imageView1;
    private ImageView imageView2;
    private ImageView imageView3;
    private EditText tags;
    private EditText finds;
    private TextView text1;
    private TextView text1dt;
    private TextView text2;
    private TextView text2dt;
    private TextView text3;
    private TextView text3dt;
    private SQLiteDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sketch_tagger);
        imageView1 = findViewById(R.id.imageView1);
        imageView2 = findViewById(R.id.imageView2);
        imageView3 = findViewById(R.id.imageView3);
        tags = findViewById(R.id.tags);
        finds = findViewById(R.id.finds);
        text1 = findViewById(R.id.text1);
        text1dt = findViewById(R.id.text1dt);
        text2 = findViewById(R.id.text2);
        text2dt = findViewById(R.id.text2dt);
        text3 = findViewById(R.id.text3);
        text3dt = findViewById(R.id.text3dt);
        mydb = this.openOrCreateDatabase("mydb", Context.MODE_PRIVATE, null);
        mydb.execSQL("CREATE TABLE IF NOT EXISTS IMAGES (IMG BLOB, DATE TEXT, TAGS TEXT)");
    }

    public void onClick(View view) {
        MyDrawingArea mcas = findViewById(R.id.drawing);
        Bitmap b = mcas.getBitmap(); //we wrote this function inside custom view
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] blob = stream.toByteArray();
        String date = new SimpleDateFormat("MMM dd, yyyy - HH:mma", Locale.US).format(new Date());
        String tag = tags.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("IMG", blob);
        cv.put("DATE", date);
        cv.put("TAGS", tag);
        mydb.insert("IMAGES", null, cv);
    }

    public void reset() {
        imageView1.setImageResource(android.R.color.transparent);
        imageView2.setImageResource(android.R.color.transparent);
        imageView3.setImageResource(android.R.color.transparent);
        text1.setText("unavailable");
        text1dt.setText("");
        text2.setText("unavailable");
        text2dt.setText("");
        text3.setText("unavailable");
        text3dt.setText("");
    }

    public void find1(View view) {
        reset();
        String tag = finds.getText().toString();
        Cursor c = mydb.rawQuery("SELECT * FROM IMAGES WHERE TAGS LIKE '%"+tag+"%'", null);
        c.moveToLast();
        for (int i = 0; i < c.getCount(); i++) {
            byte[] blob = c.getBlob(0);
            Bitmap b = BitmapFactory.decodeByteArray(blob, 0, blob.length);
            String datetime = c.getString(1);
            String name = c.getString(2);
            if (i == 0) {
                imageView1.setImageBitmap(b);
                text1.setText(name);
                text1dt.setText(datetime);
            } else if (i == 1) {
                imageView2.setImageBitmap(b);
                text2.setText(name);
                text2dt.setText(datetime);
            } else if (i == 2) {
                imageView3.setImageBitmap(b);
                text3.setText(name);
                text3dt.setText(datetime);
                i = c.getCount();
            }
            c.moveToPrevious();
        }
    }

    public void clear(View view) {
        MyDrawingArea drawing = findViewById(R.id.drawing);
        drawing.clearDrawing(); // clear function from custom view
        tags.getText().clear();
    }

    public void back1(View view) {
        Intent b = new Intent(this, MainActivity.class);
        startActivity(b);
    }
}