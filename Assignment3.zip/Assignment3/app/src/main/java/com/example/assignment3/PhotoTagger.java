package com.example.assignment3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PhotoTagger extends AppCompatActivity {
    private ImageView photoView;
    private ImageView image1;
    private ImageView image2;
    private ImageView image3;
    private EditText tags2;
    private EditText finds2;
    private TextView t1;
    private TextView dt1;
    private TextView t2;
    private TextView dt2;
    private TextView t3;
    private TextView dt3;
    private SQLiteDatabase db;
    private Bitmap image;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_tagger);
        photoView = findViewById(R.id.photoView);
        image1 = findViewById(R.id.image1);
        image2 = findViewById(R.id.image2);
        image3 = findViewById(R.id.image3);
        tags2 = findViewById(R.id.tags2);
        finds2 = findViewById(R.id.finds2);
        t1 = findViewById(R.id.t1);
        dt1 = findViewById(R.id.dt1);
        t2 = findViewById(R.id.t2);
        dt2 = findViewById(R.id.dt2);
        t3 = findViewById(R.id.t3);
        dt3 = findViewById(R.id.dt3);
        db = this.openOrCreateDatabase("db", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS PHOTOS (IMG BLOB, DATE TEXT, TAGS TEXT)");
    }

    public void startCamera(View view) {
        Intent cam_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cam_intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            image = (Bitmap) extras.get("data");
            photoView.setImageBitmap(image);
        }
    }

    public void save(View view) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] blob = stream.toByteArray();
        String date = new SimpleDateFormat("MMM dd, yyyy - HH:mma", Locale.US).format(new Date());
        String tag = tags2.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("IMG", blob);
        cv.put("DATE", date);
        cv.put("TAGS", tag);
        db.insert("PHOTOS", null, cv);
    }

    public void reset() {
        image1.setImageResource(android.R.color.transparent);
        image2.setImageResource(android.R.color.transparent);
        image3.setImageResource(android.R.color.transparent);
        t1.setText("unavailable");
        dt1.setText("");
        t2.setText("unavailable");
        dt2.setText("");
        t3.setText("unavailable");
        dt3.setText("");
    }

    public void find2(View view) {
        reset();
        String tag = finds2.getText().toString();
        Cursor c = db.rawQuery("SELECT * FROM PHOTOS WHERE TAGS LIKE '%"+tag+"%'", null);
        c.moveToLast();
        for (int i = 0; i < c.getCount(); i++) {
            byte[] blob = c.getBlob(0);
            Bitmap b = BitmapFactory.decodeByteArray(blob, 0, blob.length);
            String datetime = c.getString(1);
            String name = c.getString(2);
            if (i == 0) {
                image1.setImageBitmap(b);
                t1.setText(name);
                dt1.setText(datetime);
            } else if (i == 1) {
                image2.setImageBitmap(b);
                t2.setText(name);
                dt2.setText(datetime);
            } else if (i == 2) {
                image3.setImageBitmap(b);
                t3.setText(name);
                dt3.setText(datetime);
                i = c.getCount();
            }
            c.moveToPrevious();
        }
    }

    public void back2(View view) {
        Intent b = new Intent(this, MainActivity.class);
        startActivity(b);
    }
}