package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button photo;
    Button sketch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        photo = findViewById(R.id.photo);
        sketch = findViewById(R.id.sketch);
    }

    public void photos(View view) {
        Intent p = new Intent(this, PhotoTagger.class);
        startActivity(p);
    }

    public void sketches(View view) {
        Intent s = new Intent(this, SketchTagger.class);
        startActivity(s);
    }
}